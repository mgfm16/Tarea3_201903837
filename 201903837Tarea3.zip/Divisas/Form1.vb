﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim moneda As String
        Dim cantidadOp As Integer
        Dim texto As String
        Dim total1 As Double = 0
        Dim venta As Double = 0
        Dim compra As Double = 0



        If (RadioButton1.Checked) Then
            moneda = "dolar"

        ElseIf (RadioButton2.Checked) Then
            moneda = "peso"

        ElseIf (RadioButton3.Checked) Then
            moneda = "euro"

        ElseIf (RadioButton4.Checked) Then
            moneda = "colon"

        End If



        texto = TextBox1.Text
        If (texto = "") Then
            MsgBox("no se admiten cadenas vacias")
        Else
            cantidadOp = Int32.Parse(TextBox1.Text)
            If (cantidadOp > 0) Then

                If (moneda = "dolar") Then
                    total1 = 7.69 * cantidadOp
                    Label5.Text = total1.ToString

                ElseIf (moneda = "peso") Then
                    total1 = 0.38 * cantidadOp
                    Label5.Text = total1.ToString

                ElseIf (moneda = "euro") Then
                    total1 = 8.79 * cantidadOp
                    Label5.Text = total1.ToString

                ElseIf (moneda = "colon") Then
                    total1 = 0.012 * cantidadOp
                    Label5.Text = total1.ToString

                End If

            Else

            End If
        End If


        compra = total1 * 0.025 + total1
        Label6.Text = compra.ToString

        venta = total1 * 0.03 + total1
        Label7.Text = venta.ToString



    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        Label5.Text = "00.00"
        Label6.Text = "00.00"
        Label7.Text = "00.00"

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class
